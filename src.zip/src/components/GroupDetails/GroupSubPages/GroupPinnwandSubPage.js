import React from "react";

export default function GroupPinnwandSubPage() {
  return <div>GroupPinnwandSubPage</div>;
}
