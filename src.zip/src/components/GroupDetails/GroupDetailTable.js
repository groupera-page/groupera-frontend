import React from "react";

export default function GroupDetailTable() {
  return <div>GroupDetailTable</div>;
}
