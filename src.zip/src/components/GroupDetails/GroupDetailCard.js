import React from "react";

export default function GroupDetailCard() {
  return <div>GroupDetailCard</div>;
}
