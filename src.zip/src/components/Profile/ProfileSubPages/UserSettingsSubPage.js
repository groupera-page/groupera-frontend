import React from "react";

export default function UserSettingsSubPage() {
  return (
    <div>
      {" "}
      Not in MVP{" "}
      {/* <div className="flex flex-col p-4">
        <div className="flex flex-col my-4">
          <h4>Nachrichten</h4>
          <p className="text-TEXT_LIGHTGRAY">
            Stelle ein zu welchen Informationen du per Email benachrichtigt
            werden möchtest.{" "}
          </p>
        </div>
        <div className="flex flex-col md:w-1/4 my-4">
          <h5>Neue Gruppen</h5>
          <div className="flex">
            <p className="text-TEXT_LIGHTGRAY">
              Email erhalten, wenn es neue Gruppen zu meinem Thema gibt.
            </p>
            Switch
          </div>
        </div>
        <div className="flex flex-col md:w-1/4 my-4">
          <h5>Pinnwand</h5>
          <p className="text-TEXT_LIGHTGRAY">
            Email erhalten, wenn jemand was an die Pinnwand postet.
          </p>
        </div>
        <div className="flex flex-col md:w-1/4 my-4">
          <h5>Experte werden mit Groupera</h5>
          <p className="text-TEXT_LIGHTGRAY">
            Email erhalten, wenn es Neuigkeiten oder interessante Infos zu
            Studien, Erkrankungen etc. von we.together gibt.{" "}
          </p>
        </div>

        <hr className="border my-4" />
      </div> */}
    </div>
  );
}
