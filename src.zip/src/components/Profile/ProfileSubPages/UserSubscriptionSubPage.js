import React from "react";

export default function UserSubscriptionSubPage() {
  return <div>Not in MVP</div>;
}
