import React from "react";
import { AiOutlineWarning } from "react-icons/ai";

export default function InputError({ showMessage, errorMessage }) {
  return (
    <div
      className={`transform rounded-md border- bg-BG_PRIMARY transition-all ease-in-out duration-300 ${
        showMessage ? "translate-y-0 opacity-100" : "-translate-y-2 opacity-0"
      }`}
    >
      {showMessage && (
        <div className=" p- text- PURPLE_PRIMARY text-sm bg-BG_PRIMARY">
          <div className="flex items-center bg-BG_PRIMARY">
            <AiOutlineWarning
              className="text-red text-BG_PRIMARY bg-BG_PRIMARY"
              size={28}
            />
            <span className="ml-1 bg-BG_PRIMARY">{errorMessage}</span>
          </div>
        </div>
      )}
    </div>
  );
}
